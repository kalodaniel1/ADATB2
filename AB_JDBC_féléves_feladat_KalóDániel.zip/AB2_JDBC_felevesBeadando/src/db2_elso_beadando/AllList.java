package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AllList extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private AllTM atm;
	DbMethods dbm = new DbMethods();
	
	public AllList(JFrame f, AllTM betm) {
		super(f,"�sszevont lista", true);
		setUndecorated(true);
		atm = betm;
		setBounds(100, 100, 1000, 334);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnBezar = new JButton("Bez\u00E1r");
			btnBezar.setBackground(new Color(255, 228, 181));
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(255,228,181));
			    }
			});
			btnBezar.setBounds(439, 281, 108, 42);
			contentPanel.add(btnBezar);
			btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 11, 980, 259);
			contentPanel.add(scrollPane);
			{
				table = new JTable(atm);
				scrollPane.setViewportView(table);
			}
		}
		TableColumn tc = null;
		for (int i = 0; i < 11; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1 || i==4 || i==5 || i==6 || i==7 || i==11) tc.setPreferredWidth(20);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		{
			JButton btnWriteToFile = new JButton("Ment\u00E9s");
			btnWriteToFile.setBackground(new Color(255, 228, 181));
			btnWriteToFile.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						dbm.Connect();
						dbm.openFile("osszes.txt");
						dbm.addRecordsAll();
						dbm.closeFile();
						dbm.DisConnect();
						SM("Sikeres ki�r�s! A file megtal�lhat� osszes.txt n�ven");
					} catch (Exception e2) {
						SM("Sikertelen k��r�s: "+e2.getMessage());
					}
				}
			});
			btnWriteToFile.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnWriteToFile.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnWriteToFile.setBackground(new Color(255,228,181));
			    }
			});
			btnWriteToFile.setBounds(10, 281, 108, 42);
			contentPanel.add(btnWriteToFile);
			btnWriteToFile.setFont(new Font("Arial", Font.BOLD, 13));
		}
		TableRowSorter<AllTM> trs = (TableRowSorter<AllTM>)table.getRowSorter();
		trs.setSortable(0, false);
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}

}
