package db2_elso_beadando;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class SzinList extends JDialog {
	private JTable table;
	private SzinTM stm;
	DbMethods dbm = new DbMethods();

	public SzinList(JFrame f,SzinTM betm) {
		super(f, "Sz�ndarabok list�ja", true);
		setUndecorated(true);
		getContentPane().setBackground(new Color(250, 235, 215));
		stm = betm;
		setBounds(100, 100, 667, 357);
		getContentPane().setLayout(null);
		
		JButton btnBezar = new JButton("Bez\u00E1r\u00E1s");
		btnBezar.setBackground(new Color(255, 228, 181));
		btnBezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(255,228,181));
		    }
		});
		btnBezar.setBounds(568, 304, 89, 42);
		getContentPane().add(btnBezar);
		btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 647, 282);
		getContentPane().add(scrollPane);
		
		table = new JTable(stm);
		scrollPane.setViewportView(table);
		
		JButton btnMod = new JButton("M\u00F3dos\u00EDt\u00E1s");
		btnMod.setBackground(new Color(255, 228, 181));
		btnMod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0, jel=0, x=0;
				for (x = 0; x < stm.getRowCount(); x++) 
					if((Boolean)stm.getValueAt(x, 0)) {db++; jel=x;}
				if(db==0) SM("V�lasszon ki egy rekordot");
				if(db>1) SM("Maximum egy rekordot lehet kiv�lasztani");
				if(db==1) {
					ModSzin ms = new ModSzin(null, RTM(jel,1), RTM(jel,2), RTM(jel,3),  RTM(jel,4),  RTM(jel,5),  RTM(jel,6));
					ms.setVisible(true);
				}
			}
		});
		btnMod.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnMod.setBackground(new Color(255,228,181));
		    }
		});
		btnMod.setBounds(10, 304, 105, 42);
		getContentPane().add(btnMod);
		btnMod.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnTorol = new JButton("T\u00F6rl\u00E9s");
		btnTorol.setBackground(new Color(255, 228, 181));
		btnTorol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0,jel=0,x=0;
				for (x = 0; x < stm.getRowCount(); x++)
					if((Boolean)stm.getValueAt(x, 0)) {db++; jel=x;}
				if(db==0) SM("Nincs kijel�lve semmi");
				if(db>1) SM("Egyszerre csak egy t�r�lhet�");
				if(db==1) {
					dbm.Connect();
					dbm.DeleteSzin(RTM(jel,1));
					stm.removeRow(jel);
					dbm.DisConnect();
				}
			}
		});
		btnTorol.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnTorol.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnTorol.setBackground(new Color(255,228,181));
		    }
		});
		btnTorol.setBounds(125, 304, 89, 42);
		getContentPane().add(btnTorol);
		btnTorol.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnWriteToFile = new JButton("Ment\u00E9s");
		btnWriteToFile.setBackground(new Color(255, 228, 181));
		btnWriteToFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dbm.Connect();
					dbm.openFile("szindarab.txt");
					dbm.addRecordsSzin();
					dbm.closeFile();
					dbm.DisConnect();
					SM("Sikeres ki�r�s! A file megtal�lhat� szindarab.txt n�ven");
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnWriteToFile.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnWriteToFile.setBackground(new Color(255,228,181));
		    }
		});
		btnWriteToFile.setBounds(224, 304, 89, 42);
		getContentPane().add(btnWriteToFile);
		btnWriteToFile.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnBetolt = new JButton("Bet\u00F6lt\u00E9s");
		btnBetolt.setBackground(new Color(255, 228, 181));
		btnBetolt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.ReplaceDataSzin("szindarab.txt");
			}
		});
		btnBetolt.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBetolt.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBetolt.setBackground(new Color(255,228,181));
		    }
		});
		btnBetolt.setBounds(323, 304, 89, 42);
		getContentPane().add(btnBetolt);
		btnBetolt.setFont(new Font("Arial", Font.BOLD, 13));
		
		TableColumn tc = null;
		for (int i = 0; i < 7; i++) {
			tc = table.getColumnModel().getColumn(i);
			if(i==0 || i==1 || i==4 || i==5 || i==6) tc.setPreferredWidth(30);
			else {tc.setPreferredWidth(100);
		}
			
		table.setAutoCreateRowSorter(true);
		TableRowSorter<SzinTM> trs = (TableRowSorter<SzinTM>)table.getRowSorter();
		trs.setSortable(0, false);
		}
	}
	
	public String RTM(int row,int col) {
		return stm.getValueAt(row, col).toString();
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
	
}
