package db2_elso_beadando;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Formatter;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class DbMethods {
	
	private Statement s = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;
	private Formatter x;
	
	//Minden adat kiolvas�sa
	public AllTM ReadAllData() {
		Object alltmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma","Rendsz�ma","N�v","Sz�let�si id�","V�ros","Magass�g"};
		AllTM atm = new AllTM(alltmn, 0);
		String nev="", szulido="", lak="", cim="", mikor="";
		int rid=0, magassag=0;
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from rendezo r left join szindarab sz on r.rid = sz.rendezo";
		try {
			s = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				atm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo,rid,nev,szulido,lak,magassag+" cm"});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return atm;
	}
	
	//Bejelentkez�s
	public int Identification(String name, String pswd) {
		Connect();
		int pc = -1;
		String sql = "select count(*) pc from user where name='"+name+"' and pswd='"+pswd+"';";
		try {
			s = conn.createStatement();
			rs=s.executeQuery(sql);
			while(rs.next()) {
				pc=rs.getInt("pc");
			}
			rs.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
		return pc;
	}
	
	//Rendez�k kiolvas�sa
	public RenTM ReadAllDataRend() {
		Object rentmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magass�g"};
		RenTM rentm = new RenTM(rentmn, 0);
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		String sql = "Select * from rendezo";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				rentm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return rentm;
	}
	
	//Sz�ndarabok kiolvas�sa
	public SzinTM ReadAllDataSzin() {
		Object szintmn[] = {"Jel","K�d","C�m","Indul�s","�r","J�t�kid�","Rendez� sz�ma"};
		SzinTM stm = new SzinTM(szintmn,0);
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				stm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return stm;
	}
	
	//Kapcsol�d�s
	public void Connect() {
		try {
			//jdbc:sqlite:C:/Users/dani5/AppData/Local/VirtualStore/Program Files/SQLite/elsobeadandodb.db
			String url = "jdbc:sqlite:src/elsobeadandodb.db";
			conn = DriverManager.getConnection(url);
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}
	
	//Lekapcsol�d�s
	public void DisConnect() {
		try {
			conn.close();
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}
	
	//Driver Regiszt�r�l�s
	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
			SM("Sikeres regisztr�ci�!");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!"+e.getMessage());
		}
	}
	
	//�zenet ki�rat�
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
	
	//Sz�ndarab felvitel
	public void InsertSzin(String szid,String cim,String mikor,String ar,String jatekido,String rendezo) {
		
		String sql = "insert into szindarab values ("+szid+", '"+cim+"', '"+mikor+"', "+ar+", "+jatekido+", "+ rendezo +")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: "+e.getMessage());
		}
	}
	
	//Rendez� felvitel
	public void InsertRen(String rid,String nev,String szulido,String lak,String magassag) {
		
		String sql = "insert into rendezo values ("+rid+", '"+nev+"', '"+szulido+"', '"+lak+"', "+magassag+")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: "+e.getMessage());
		}
	}
	
	//Sz�ndarab m�dos�t�s
	public void UpdateSzin(String szid,String cim,String mikor,String ar,String jatekido,String rendezo) {
		String sql = "update szindarab set cim= '"+cim+"', mikor= '"+mikor+"', ar= "+ar+", jatekido= "+jatekido+", rendezo= "+rendezo+" where szid= "+szid;
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Update OK!");
		} catch (Exception e) {
			SM("JDBC Udpate: "+e.getMessage());
		}
	}
	
	//Rendez� M�dos�t�s
	public void UpdateRen(String rid,String nev,String szulido,String lak,String magassag) {
		String sql = "update rendezo set nev= '"+nev+"', szulido= '"+szulido+"', lak= '"+lak+"', magassag= "+magassag+" where rid= "+rid;
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Update OK!");
		} catch (Exception e) {
			SM("JDBC Udpate: "+e.getMessage());
		}
	}
	
	//Sz�ndarab t�rl�se
	public void DeleteSzin(String szid) {
		String sql = "delete from szindarab where szid="+szid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}
	
	//Rendez� t�rl�se
	public void DeleteRen(String rid) {
		String sql = "delete from rendezo where rid="+rid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}
	
	//Sz�r�s1
	public Szures1TM ReadDataSzures1(String varos) {
		Object s1tmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magass�g"};
		Szures1TM s1tm = new Szures1TM(s1tmn, 0);
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		int db=0;
		String sql = "Select * from rendezo where lak ='"+varos+"'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				s1tm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if(db==0) {
			rid = 0;
			nev = "Hib�s adat";
			szulido = "";
			lak = "";
			magassag= 0;
			s1tm.addRow(new Object[] {false,rid,nev,szulido,lak,magassag});
		}
		return s1tm;
	}
	
	//Sz�r�s2
	public Szures2TM ReadDataSzures2(String nev) {
		Object s2tmn[] = {"Jel","N�v","Elk�sz�tett darabok"};
		Szures2TM s2tm = new Szures2TM(s2tmn, 0);
		int count=0;
		String strnev;
		String sql = "Select r.nev,count(sz.szid) darabszam from rendezo r inner join szindarab sz on r.rid=sz.rendezo where r.nev = ?";
		try {
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, nev);
			rs=ps.executeQuery();
			conn.commit();
			while(rs.next()) {
				strnev = rs.getString("nev");
				count= rs.getInt("darabszam");
				s2tm.addRow(new Object[] {false,strnev,count});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s2tm;
	}
	
	//Sz�r�s3
	public Szures3TM ReadDataSzures3(String nev2) {
		Object s3tmn[] = {"Jel","N�v","Leghosszabb darab"};
		Szures3TM s3tm = new Szures3TM(s3tmn, 0);
		String strnev2;
		int hossz=0;
		String sql = "Select r.nev,max(jatekido) leghosszabb from rendezo r inner join szindarab sz on r.rid=sz.rendezo where r.nev = ?";
		try {
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, nev2);
			rs=ps.executeQuery();
			conn.commit();
			while(rs.next()) {
				strnev2 = rs.getString("nev");
				hossz= rs.getInt("leghosszabb");
				s3tm.addRow(new Object[] {false,strnev2,hossz});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s3tm;
	}
	
	//Sz�r�s4
	public Szures4TM ReadDataSzures4(int alsohatar, int felsohatar) {
		Object s4tmn[] = {"Jel","K��d","C�m","Mikor","�r","J�t�kid�","Rendez�"};
		Szures4TM s4tm = new Szures4TM(s4tmn, 0);
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab where jatekido between "+alsohatar+" and "+felsohatar;
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				s4tm.addRow(new Object[] {false,szid,cim,mikor,ar,jatekido,rendezo});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s4tm;
	}
	
	//Sz�r�s5
	public Szures5TM ReadDataSzures5() {
		Object s5tmn[] = {"Jel","C�m","J�t�kid�"};
		Szures5TM s5tm = new Szures5TM(s5tmn, 0);
		String cim;
		int jatekido=0;
		String sql = "Select cim,jatekido from szindarab where jatekido > 60";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				cim = rs.getString("cim");
				jatekido= rs.getInt("jatekido");
				s5tm.addRow(new Object[] {false,cim,jatekido});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s5tm;
	}
	
	//Sz�r�s6
	public Szures6TM ReadDataSzures6() {
		Object s6tmn[] = {"Jel","N�v"};
		Szures6TM s6tm = new Szures6TM(s6tmn, 0);
		String nev;
		int atlaghossz=0;
		//CREATE VIEW atlaghossz AS SELECT r.nev, AVG(sz.jatekido) mjatekido FROM rendezo r INNER JOIN szindarab sz ON r.rid = sz.rendezo GROUP BY r.nev
		String sql = "SELECT nev FROM atlaghossz WHERE mjatekido =(SELECT MAX(mjatekido) FROM atlaghossz)";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				nev = rs.getString("nev");
				s6tm.addRow(new Object[] {false,nev});
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return s6tm;
	}
	
	//F�jl megnyit�sa
	public void openFile(String txtName) {
		try {
			x = new Formatter(txtName);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	//F�jl Bez�r�sa
	public void closeFile() {
		x.close();
	}
	
	//szindarab.txt felt�lt�se
	public void addRecordsSzin() {
		String cim="", mikor="";
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from szindarab";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				x.format(szid+";"+cim+";"+mikor+";"+ar+";"+jatekido+";"+rendezo+"\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	//rendezo.txt felt�lt�se
	public void addRecordsRend() {
		String nev="", szulido="", lak="";
		int rid=0, magassag=0;
		String sql = "Select * from rendezo";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				x.format(rid+";"+nev+";"+szulido+";"+lak+";"+magassag+"\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	//osszes.txt felt�lt�se
	public void addRecordsAll() {
		String nev="", szulido="", lak="", cim="", mikor="";
		int rid=0, magassag=0;
		int szid=0, ar=0, jatekido =0, rendezo=0;
		String sql = "Select * from rendezo r left join szindarab sz on r.rid = sz.rendezo";
		try {
			s = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			rs = s.executeQuery(sql);
			while(rs.next()) {
				rid = rs.getInt("rid");
				nev = rs.getString("nev");
				szulido = rs.getString("szulido");
				lak = rs.getString("lak");
				magassag= rs.getInt("magassag");
				szid = rs.getInt("szid");
				cim = rs.getString("cim");
				mikor = rs.getString("mikor");
				ar = rs.getInt("ar");
				jatekido= rs.getInt("jatekido");
				rendezo= rs.getInt("rendezo");
				x.format("K�d: "+szid+", C�m: "+cim+", Premier: "+mikor+", Jegy �r: "+ar+" Ft, J�t�kid�: "+jatekido+" perc, Rendez� k�d: "+rendezo+", N�v: "+nev+", Sz�let�si id�: "+szulido+", Lakhely: "+lak+", Magass�g: "+magassag+" cm\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}
	
	//T�bl�k nev�nek lek�r�se
	public void getTables() {
		 try {
			 int i=1;
			  DatabaseMetaData metaData = conn.getMetaData();
		      String[] types = {"TABLE"};
		      ResultSet tables = metaData.getTables(null, null, "%", types);
		      while (tables.next()) {
		         SM(i+". t�bla neve: "+tables.getString("TABLE_NAME"));
		         i++;
		      }
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	
	//Sz�ndarabok bet�lt�se txt-b�l
	public void ReplaceDataSzin(String file) {
		String sql ="";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf=in.readLine();
			while(sf!=null) {
				String[] st=sf.split(";");
				sql = "replace into szindarab values("+st[0]+", '"+st[1]+"', '"+st[2]+"', "+st[3]+", "+st[4]+", "+st[5]+")";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok felt�lve");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: "+e.getMessage());
		}
	}
	
	//Rendez�k bet�lt�se txt-b�l
	public void ReplaceDataRend(String file) {
		String sql ="";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf=in.readLine();
			while(sf!=null) {
				String[] st=sf.split(";");
				sql = "replace into rendezo values("+st[0]+", '"+st[1]+"', '"+st[2]+"', '"+st[3]+"', "+st[4]+")";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok felt�lve");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: "+e.getMessage());
		}
	}
	
	//Rendez� k�djai a leg�rd�l� ablakokhoz
	public ArrayList<String> readRid() {
		String sql = "Select rid from rendezo";
		ArrayList<String> ridStr = new ArrayList<String>();
		ridStr.add("V�lassz!");
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while(rs.next()) {
				ridStr.add(rs.getString("rid"));
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return ridStr;
	}
	
}