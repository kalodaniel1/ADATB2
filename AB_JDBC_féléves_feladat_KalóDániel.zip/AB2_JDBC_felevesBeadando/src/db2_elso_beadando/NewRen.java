package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class NewRen extends JDialog {
	DbMethods dbm = new DbMethods();
	private final JPanel contentPanel = new JPanel();
	private JTextField rid;
	private JTextField nev;
	private JTextField szulido;
	private JTextField lak;
	private JTextField magassag;

	public NewRen(JFrame f) {
		super(f,"�j rendez� felvitele", true);
		setBounds(100, 100, 373, 201);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("K\u00F3d:");
			lblNewLabel.setBounds(10, 11, 74, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("N\u00E9v:");
			lblNewLabel_1.setBounds(10, 36, 74, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Sz\u00FClet\u00E9si id\u0151:");
			lblNewLabel_2.setBounds(10, 61, 97, 14);
			contentPanel.add(lblNewLabel_2);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("Lakhely:");
			lblNewLabel_3.setBounds(10, 86, 86, 14);
			contentPanel.add(lblNewLabel_3);
		}
		{
			JLabel lblNewLabel_4 = new JLabel("Magass\u00E1g:");
			lblNewLabel_4.setBounds(10, 111, 97, 14);
			contentPanel.add(lblNewLabel_4);
		}
		{
			rid = new JTextField();
			rid.setBounds(117, 11, 86, 20);
			contentPanel.add(rid);
			rid.setColumns(10);
		}
		{
			nev = new JTextField();
			nev.setText("");
			nev.setBounds(117, 36, 174, 20);
			contentPanel.add(nev);
			nev.setColumns(10);
		}
		{
			szulido = new JTextField();
			szulido.setText("");
			szulido.setBounds(117, 61, 109, 20);
			contentPanel.add(szulido);
			szulido.setColumns(10);
		}
		{
			lak = new JTextField();
			lak.setText("");
			lak.setBounds(117, 86, 174, 20);
			contentPanel.add(lak);
			lak.setColumns(10);
		}
		{
			magassag = new JTextField();
			magassag.setText("");
			magassag.setBounds(117, 111, 86, 20);
			contentPanel.add(magassag);
			magassag.setColumns(10);
		}
		{
			JButton btnBeszur = new JButton("Besz\u00FAr\u00E1s");
			btnBeszur.setBackground(new Color(255, 228, 181));
			btnBeszur.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!filledTF(rid)) SM("A k�d mez� �res");
					else if(!goodInt(rid)) SM("A k�d mez� nem helyes");
					else if(!filledTF(nev)) SM("A n�v mez� �res");
					else if(!filledTF(szulido)) SM("A sz�let�si id� �res");
					else if(!goodDate(szulido)) SM("A sz�let�si id� helytelen");
					else if(!filledTF(lak)) SM("A lak�hely mez� �res");
					else if(!filledTF(magassag)) SM("A magass�g mez� �res");
					else if(!goodInt(magassag)) SM("A magass�g mez� helytelen");
					dbm.Connect();
					dbm.InsertRen(RTF(rid), RTF(nev), RTF(szulido), RTF(lak), RTF(magassag));
					dbm.DisConnect();
				}
			});
			btnBeszur.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnBeszur.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnBeszur.setBackground(new Color(255,228,181));
			    }
			});
			btnBeszur.setBounds(224, 128, 123, 23);
			contentPanel.add(btnBeszur);
			btnBeszur.setFont(new Font("Arial", Font.BOLD, 13));
		}
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
