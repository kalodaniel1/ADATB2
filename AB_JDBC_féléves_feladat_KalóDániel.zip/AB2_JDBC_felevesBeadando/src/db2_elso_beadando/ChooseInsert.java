package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class ChooseInsert extends JDialog {

	private final JPanel contentPanel = new JPanel();

	public ChooseInsert() {
		setUndecorated(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Melyik t\u00E1bl\u00E1ba szeretne beilleszteni?");
			lblNewLabel.setBounds(129, 46, 295, 44);
			contentPanel.add(lblNewLabel);
		}
		{
			JButton btnSzin = new JButton("Sz\u00EDndarab");
			btnSzin.setBackground(new Color(255, 228, 181));
			btnSzin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					NewSzin ns = new NewSzin(null);
					ns.setVisible(true);
				}
			});
			btnSzin.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnSzin.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnSzin.setBackground(new Color(255,228,181));
			    }
			});
			btnSzin.setBounds(49, 170, 120, 44);
			contentPanel.add(btnSzin);
			btnSzin.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			JButton btnRen = new JButton("Rendez\u0151");
			btnRen.setBackground(new Color(255, 228, 181));
			btnRen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					NewRen nr = new NewRen(null);
					nr.setVisible(true);
				}
			});
			btnRen.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnRen.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnRen.setBackground(new Color(255,228,181));
			    }
			});
			btnRen.setBounds(266, 170, 120, 44);
			contentPanel.add(btnRen);
			btnRen.setFont(new Font("Arial", Font.BOLD, 13));
		}
		{
			JButton btnBezar = new JButton("Bez\u00E1r");
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(255,228,181));
			    }
			});
			btnBezar.setBackground(new Color(255, 228, 181));
			btnBezar.setBounds(180, 245, 89, 44);
			contentPanel.add(btnBezar);
			btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		}
	}
}
