package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Szures6List extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private Szures6TM s6tm;

	public Szures6List(Szurok szurok,Szures6TM betm) {
		super(szurok,"Lista", true);
		setUndecorated(true);
		s6tm = betm;
		setBounds(100, 100, 599, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnBezar = new JButton("Bez\u00E1r");
			btnBezar.setBackground(new Color(255, 228, 181));
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnBezar.setBackground(new Color(255,228,181));
			    }
			});
			btnBezar.setBounds(253, 255, 89, 34);
			contentPanel.add(btnBezar);
			btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 579, 233);
		contentPanel.add(scrollPane);
		
		table = new JTable(s6tm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 2; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0) tc.setPreferredWidth(30);
		else {tc.setPreferredWidth(100);}
		}
		table.setAutoCreateRowSorter(true);
		TableRowSorter<Szures6TM> trs =
		(TableRowSorter<Szures6TM>)table.getRowSorter();
		trs.setSortable(0, false);
		
	}
}
