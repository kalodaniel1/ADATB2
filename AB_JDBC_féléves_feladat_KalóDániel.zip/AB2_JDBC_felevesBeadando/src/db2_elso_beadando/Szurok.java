package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class Szurok extends JDialog {
	DbMethods dbm = new DbMethods();
	private Szures1TM s1tm;
	private Szures2TM s2tm;
	private Szures3TM s3tm;
	private Szures4TM s4tm;
	private Szures5TM s5tm;
	private Szures6TM s6tm;
	private JTextField varos;
	private final JPanel contentPanel = new JPanel();
	private final JTextField nev = new JTextField();
	private final JButton btnSzures2 = new JButton("Sz\u0171r\u00E9s");
	private final JTextField nev2 = new JTextField();
	private final JButton btnSzures3 = new JButton("Sz\u0171r\u00E9s");
	private final JLabel lblNewLabel = new JLabel("Azon darabok amelyek");
	private JTextField alsohatar;
	private JTextField felsohatar;

	public Szurok() {
		setUndecorated(true);
		nev2.setHorizontalAlignment(SwingConstants.CENTER);
		nev2.setBounds(10, 131, 352, 20);
		nev2.setColumns(10);
		nev.setHorizontalAlignment(SwingConstants.CENTER);
		nev.setBounds(10, 80, 352, 20);
		nev.setColumns(10);
		setBounds(100, 100, 563, 364);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		varos = new JTextField();
		varos.setHorizontalAlignment(SwingConstants.CENTER);
		varos.setBounds(10, 34, 322, 20);
		contentPanel.add(varos);
		varos.setColumns(10);
		
		JButton btnSzures1 = new JButton("Sz\u0171r\u00E9s");
		btnSzures1.setBackground(new Color(255, 228, 181));
		btnSzures1.setBounds(342, 33, 89, 23);
		btnSzures1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filledTF(varos)) SM("�rjon be egy v�ros nevet!");
				else if(!goodString(varos)) SM("Ne sz�mokat adjon meg!");
				else {
					dbm.Connect();
					s1tm = dbm.ReadDataSzures1(RTF(varos));
					dbm.DisConnect();
					Szures1List s1 = new Szures1List(Szurok.this,s1tm);
					s1.setVisible(true);
				}
			}
		});
		btnSzures1.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures1.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures1.setBackground(new Color(255,228,181));
		    }
		});
		contentPanel.add(btnSzures1);
		btnSzures1.setFont(new Font("Arial", Font.BOLD, 13));
		
		contentPanel.add(nev);
		btnSzures2.setBackground(new Color(255, 228, 181));
		btnSzures2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filledTF(nev)) SM("�rjon be egy nevet!");
				else if(!goodString(nev)) SM("Ne sz�mokat adjon meg!");
				else {
					dbm.Connect();
					s2tm = dbm.ReadDataSzures2(RTF(nev));
					dbm.DisConnect();
					Szures2List s2 = new Szures2List(Szurok.this,s2tm);
					s2.setVisible(true);
				}
			}
		});
		btnSzures2.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures2.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures2.setBackground(new Color(255,228,181));
		    }
		});
		btnSzures2.setBounds(372, 79, 89, 23);
		btnSzures2.setFont(new Font("Arial", Font.BOLD, 13));
		contentPanel.add(btnSzures2);
		
		contentPanel.add(nev2);
		btnSzures3.setBackground(new Color(255, 228, 181));
		btnSzures3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filledTF(nev2)) SM("�rjon be egy nevet!");
				else if(!goodString(nev2)) SM("Ne sz�mokat adjon meg!");
				else {
					dbm.Connect();
					s3tm = dbm.ReadDataSzures3(RTF(nev2));
					dbm.DisConnect();
					Szures3List s3 = new Szures3List(Szurok.this,s3tm);
					s3.setVisible(true);
				}
			}
		});
		btnSzures3.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures3.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures3.setBackground(new Color(255,228,181));
		    }
		});
		btnSzures3.setBounds(372, 130, 89, 23);
		btnSzures3.setFont(new Font("Arial", Font.BOLD, 13));
		contentPanel.add(btnSzures3);
		lblNewLabel.setBounds(10, 162, 137, 14);
		
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u00E9s");
		lblNewLabel_1.setBounds(227, 162, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("perc k\u00F6z\u00F6tt vannak");
		lblNewLabel_2.setBounds(320, 162, 111, 14);
		contentPanel.add(lblNewLabel_2);
		
		JButton btnSzures4 = new JButton("Sz\u0171r\u00E9s");
		btnSzures4.setBackground(new Color(255, 228, 181));
		btnSzures4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int also=0,felso=0;
				try {
					String alsohat = RTF(alsohatar);
					also = Integer.parseInt(alsohat);
					String felsohat = RTF(felsohatar);
					felso = Integer.parseInt(felsohat);
				} catch (Exception e2) {
					SM("Hib�s bevitt adat: "+e2.getMessage());
				}
				if(also>felso) SM("A fels� hat�rnak nagyobbnak kell lennie!");
				else if(also<0 || felso<0) SM("Nem adhat meg negat�v sz�mot");
				else if(!filledTF(alsohatar)) SM("Az als� hat�r �res!");
				else if(!filledTF(felsohatar)) SM("A fels� hat�r �res!");
				else if(!goodInt(alsohatar)) SM("Az als� hat�r nem helyes!");
				else if(!goodInt(felsohatar)) SM("A fels� hat�r nem helyes!");
				else {
					dbm.Connect();
					s4tm = dbm.ReadDataSzures4(also, felso);
					dbm.DisConnect();
					Szures4List s4 = new Szures4List(Szurok.this,s4tm);
					s4.setVisible(true);
				}
			}
		});
		btnSzures4.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures4.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures4.setBackground(new Color(255,228,181));
		    }
		});
		btnSzures4.setBounds(448, 158, 89, 23);
		contentPanel.add(btnSzures4);
		btnSzures4.setFont(new Font("Arial", Font.BOLD, 13));
		
		JLabel lblNewLabel_3 = new JLabel("1 \u00F3r\u00E1n\u00E1l hosszabb darabok c\u00EDme:");
		lblNewLabel_3.setBounds(10, 204, 193, 14);
		contentPanel.add(lblNewLabel_3);
		
		JButton btnSzures5 = new JButton("Sz\u0171r\u00E9s");
		btnSzures5.setBackground(new Color(255, 228, 181));
		btnSzures5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				s5tm = dbm.ReadDataSzures5();
				dbm.DisConnect();
				Szures5List s5 = new Szures5List(Szurok.this,s5tm);
				s5.setVisible(true);
			}
		});
		btnSzures5.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures5.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures5.setBackground(new Color(255,228,181));
		    }
		});
		btnSzures5.setBounds(221, 200, 89, 23);
		contentPanel.add(btnSzures5);
		btnSzures5.setFont(new Font("Arial", Font.BOLD, 13));
		
		JButton btnSzures6 = new JButton("Sz\u0171r\u00E9s");
		btnSzures6.setBackground(new Color(255, 228, 181));
		btnSzures6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				s6tm = dbm.ReadDataSzures6();
				dbm.DisConnect();
				Szures6List s6 = new Szures6List(Szurok.this,s6tm);
				s6.setVisible(true);
				
			}
		});
		btnSzures6.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnSzures6.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnSzures6.setBackground(new Color(255,228,181));
		    }
		});
		btnSzures6.setBounds(405, 229, 89, 23);
		contentPanel.add(btnSzures6);
		btnSzures6.setFont(new Font("Arial", Font.BOLD, 13));
		
		JLabel lblNewLabel_6 = new JLabel("\u00CDrjon be egy v\u00E1rost \u00E9s megkapja az ott \u00E9l\u0151 rendez\u0151ket");
		lblNewLabel_6.setBounds(10, 22, 352, 14);
		contentPanel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Ide \u00EDrja a rendez\u0151 nev\u00E9t \u00E9s megkapja h\u00E1ny sz\u00EDndarabot rendezett");
		lblNewLabel_7.setBounds(10, 65, 386, 14);
		contentPanel.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Ide \u00EDrja a rendez\u0151 nev\u00E9t \u00E9s megkapja a leghosszabb rendezett darabj\u00E1t");
		lblNewLabel_8.setBounds(10, 111, 451, 14);
		contentPanel.add(lblNewLabel_8);
		
		alsohatar = new JTextField();
		alsohatar.setHorizontalAlignment(SwingConstants.CENTER);
		alsohatar.setBounds(149, 159, 68, 20);
		contentPanel.add(alsohatar);
		alsohatar.setColumns(10);
		
		felsohatar = new JTextField();
		felsohatar.setHorizontalAlignment(SwingConstants.CENTER);
		felsohatar.setText("");
		felsohatar.setBounds(246, 159, 68, 20);
		contentPanel.add(felsohatar);
		felsohatar.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Melyik rendez\u0151n\u00E9l a legnagyobb a rendezett darabok \u00E1tlaghossza?");
		lblNewLabel_4.setBounds(10, 233, 385, 14);
		contentPanel.add(lblNewLabel_4);
		
		JButton btnBezar = new JButton("Bez\u00E1r");
		btnBezar.setBackground(new Color(255, 228, 181));
		btnBezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBezar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(212,189,113));
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		        btnBezar.setBackground(new Color(255,228,181));
		    }
		});
		btnBezar.setBounds(243, 313, 89, 40);
		contentPanel.add(btnBezar);
		btnBezar.setFont(new Font("Arial", Font.BOLD, 13));
		
		Object s1tmn[] = {"Jel","K�d","N�v","Sz�lid�","Lak�hely","Magassag"};
		s1tm = new Szures1TM(s1tmn, 0);
		
		Object s2tmn[] = {"Jel","N�v","Darabsz�m"};
		s2tm = new Szures2TM(s2tmn, 0);

		Object s3tmn[] = {"Jel","N�v","Leghosszabb darab"};
		s3tm = new Szures3TM(s3tmn, 0);
		
		Object s4tmn[] = {"Jel","K�d","C�m","Mikor","�r","J�t�kid�","Rendez�"};
		s4tm = new Szures4TM(s4tmn, 0);
		
		Object s5tmn[] = {"Jel","C�m","J�t�kid�"};
		s5tm = new Szures5TM(s5tmn, 0);
		
		Object s6tmn[] = {"Jel","N�v"};
		s6tm = new Szures6TM(s6tmn, 0);

	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	public boolean goodString(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return false;
		} catch (Exception e) {
			return true;
		}
	}
}
