package db2_elso_beadando;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class Login extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField username;
	private JTextField pwd;
	private JPanel contentPane;
	DbMethods dbm = new DbMethods();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	

	public Login() {
		setUndecorated(true);
		setBounds(100, 100, 575, 395);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(250, 235, 215));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnLogin = new JButton("Bejelentkez\u00E9s");
			btnLogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int pc = dbm.Identification(RTF(username), RTF(pwd));
					if(pc==1) {
						ABKezeloProg abkezel = new ABKezeloProg(Login.this);
						abkezel.setVisible(true);
						dispose();
					}
					else {
						SM("Sikertelen bejelentkez�s");
						System.exit(0);
					}
					
				}
			});
			btnLogin.setBackground(new Color(255, 228, 181));
			btnLogin.setBounds(223, 285, 123, 69);
			contentPanel.add(btnLogin);
			btnLogin.setFont(new Font("Arial", Font.BOLD, 13));
			btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
			    public void mouseEntered(java.awt.event.MouseEvent evt) {
			        btnLogin.setBackground(new Color(212,189,113));
			    }

			    public void mouseExited(java.awt.event.MouseEvent evt) {
			        btnLogin.setBackground(new Color(255,228,181));
			    }
			});
		}
		{
			username = new JTextField("");
			username.setBounds(152, 173, 346, 25);
			contentPanel.add(username);
			username.setColumns(10);
		}
		{
			pwd = new JTextField("");
			pwd.setBounds(152, 209, 346, 25);
			contentPanel.add(pwd);
			pwd.setColumns(10);
		}
		{
			JLabel lblNewLabel = new JLabel("Felhaszn\u00E1l\u00F3n\u00E9v:");
			lblNewLabel.setBounds(42, 178, 456, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Jelsz\u00F3");
			lblNewLabel_1.setBounds(42, 214, 456, 14);
			contentPanel.add(lblNewLabel_1);
		}
		
		ImageIcon icon = new ImageIcon("logo.png");
		String logo = "src/logo.png";
		JLabel lblLogo = new JLabel(new ImageIcon(logo));
		lblLogo.setBounds(73, 23, 414, 107);
		contentPanel.add(lblLogo);
		{
			JLabel lblX = new JLabel("X");
			lblX.setHorizontalAlignment(SwingConstants.CENTER);
			lblX.setBounds(545, 11, 20, 20);
			contentPanel.add(lblX);
			lblX.setFont(new Font("Arial", Font.BOLD, 13));
			lblX.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e) {
					lblX.setForeground(new Color(255,0,0));
					
				}
				public void mouseExited(MouseEvent e) {
					lblX.setForeground(new Color(0,0,0));
				}
			});
			lblX.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent arg0) {
					if(JOptionPane.showConfirmDialog(null, "Biztos, hogy ki akar l�pni?", "Biztos?", JOptionPane.YES_NO_OPTION)==0) {
						Login.this.dispose();
					}
				}
			});
		}
		
	}
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
}
